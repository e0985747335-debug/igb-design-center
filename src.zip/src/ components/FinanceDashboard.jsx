import React, { useState } from 'react';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';

export default function FinanceDashboard() {
  const [currentModule, setCurrentModule] = useState('finance');

  const renderModule = () => {
    switch (currentModule) {
      case 'finance':
        return <div className="p-6">💰 財務模組內容</div>;
      case 'hr':
        return <div className="p-6">👥 人事模組內容</div>;
      case 'project':
        return <div className="p-6">📊 專案模組內容</div>;
      default:
        return <div className="p-6">請選擇模組</div>;
    }
  };

  return (
    <div className="flex">
      <Sidebar onSelectModule={setCurrentModule} />
      <main className="flex-1 bg-gray-50">
        <Header title="企業整合儀表板 (Enterprise Dashboard)" />
        {renderModule()}
      </main>
    </div>
  );
}
