import os
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional

# 設定檔案的基礎目錄
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class Settings(BaseSettings):
    """
    應用程式的環境設定。
    設定檔會從 .env 文件中讀取。
    """
    
    # 【修復】: 增加 APP_NAME 屬性，以供 app/server.py 使用
    APP_NAME: str = "IGB Design Center API" # 給予一個預設值

    # 資料庫設定
    # 保持與 app/core/database.py 中使用的名稱一致
    SQLALCHEMY_DATABASE_URL: str = "sqlite:///./sql_app.db"
    
    # API 相關設定
    API_V1_STR: str = "/api/v1"
    
    # 允許 CORS 的來源
    BACKEND_CORS_ORIGINS: list[str] = ["*"] 

    # Pydantic v2 設定
    model_config = SettingsConfigDict(
        env_file=os.path.join(BASE_DIR, ".env"), 
        extra='ignore' # 忽略 .env 中未在 Settings 中定義的變數
    )

settings = Settings()

