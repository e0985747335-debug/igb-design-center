from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class ItemBase(BaseModel):
    sku: str = Field(..., example="APL-001")
    name: str = Field(..., example="新鮮蘋果")
    description: Optional[str] = Field(None, example="本地直送")
    price: float = Field(..., ge=0, example=50.0)
    cost: float = Field(..., ge=0, example=30.0)
    stock: int = Field(..., ge=0, example=10)
    unit: Optional[str] = Field("個", example="個")

class ItemCreate(ItemBase):
    pass

class ItemUpdate(BaseModel):
    name: Optional[str]
    description: Optional[str]
    price: Optional[float]
    cost: Optional[float]
    stock: Optional[int]
    unit: Optional[str]

class ItemOut(ItemBase):
    id: int
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    class Config:
        orm_mode = True
