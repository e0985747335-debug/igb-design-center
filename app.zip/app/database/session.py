from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# 假設您的設定檔在 app.core.config 中
from app.core.config import settings

# ----------------------------------------------------
# 1. 資料庫連線引擎設定
# ----------------------------------------------------
# 這是 SQLALchemy 連線的入口點。
# 'check_same_thread=False' 僅用於 SQLite，因為它不支援多個執行緒同時操作。
# 對於 PostgreSQL 或 MySQL 則不需要這個參數。
# 這裡使用 settings.SQLALCHEMY_DATABASE_URL 來自 app.core.config
engine = create_engine(
    settings.SQLALCHEMY_DATABASE_URL, 
    pool_pre_ping=True, 
    # 如果您使用 SQLite，請解除註釋下方這一行
    # connect_args={"check_same_thread": False} 
)

# ----------------------------------------------------
# 2. 本地會話設定
# ----------------------------------------------------
# 用於創建資料庫會話，Autocommit 設為 False 確保我們手動管理事務。
SessionLocal = sessionmaker(
    autocommit=False, 
    autoflush=False, 
    bind=engine
)

# ----------------------------------------------------
# 3. FastAPI 依賴項：get_db
# ----------------------------------------------------
# 這是一個生成器函數 (Generator Function)，用於 FastAPI 的依賴注入。
# 它確保每個請求都獲得一個獨立的 DB 會話，並在請求完成時自動關閉。
def get_db():
    """
    提供一個獨立的資料庫連線會話，並在退出時確保會話關閉。
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 注意：如果您的 app/database/__init__.py 檔案是空的，您可能還需要在其中添加一行：
# from .session import SessionLocal, engine, get_db
# 這樣其他模組才能直接從 app.database 導入 get_db。
# 如果它不是空的，請檢查內容並添加必要的導入。
