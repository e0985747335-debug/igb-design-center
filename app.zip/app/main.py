from fastapi import FastAPI
from pydantic import BaseModel
from typing import List

# 1. 從 db 資料夾引入資料庫和模型定義
# 確保 db/inventory.py 已經包含 Module Pydantic 模型和 modules_db 列表
from db.inventory import Module, modules_db

# 2. 引入我們剛剛建立的路由檔案
from routers import modules as modules_router

# 初始化 FastAPI 應用程式
app = FastAPI(
    title="供應鏈模組管理系統 API",
    description="管理公司採購的電子零組件和軟體模組的 API 服務。",
    version="1.0.1",
)

# --- 註冊路由檔案 (新增這一行) ---
# 這一行將 routers/modules.py 內定義的所有路由（以 /modules 開頭）加入到主應用程式中
app.include_router(modules_router.router)
# -----------------------------------


@app.get("/", summary="健康檢查")
def read_root():
    """
    應用程式的健康檢查端點，確認服務是否正在運行。
    """
    return {"message": "API 服務運行中！請訪問 /docs 查看文件。"}

# 範例：一個未被移動的簡單路由
@app.get("/status", summary="伺服器狀態")
def server_status():
    return {"status": "OK", "version": app.version}

# 注意：原始所有與 /modules 相關的 GET, POST, PUT, DELETE 路由定義已從此檔案移除，
# 轉移至 routers/modules.py 中。

# 如果您還有其他舊的 /modules 相關路由，請將它們刪除。
